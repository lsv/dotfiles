public function test${CAPITALIZED_NAME}(): void
{

}